# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 12-auth-roles.spec.js >> Auth & Role access control >> contractor cannot access /admin/users
- Location: tests\e2e\12-auth-roles.spec.js:90:3

# Error details

```
TimeoutError: page.waitForURL: Timeout 15000ms exceeded.
=========================== logs ===========================
waiting for navigation to "**/login" until "load"
============================================================
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic [ref=e5]: "403"
  - heading "Access Denied" [level=1] [ref=e6]
  - paragraph [ref=e7]:
    - text: Your role
    - strong
    - text: does not have permission to view this page.
  - generic [ref=e8]:
    - button "Go to my dashboard" [ref=e9] [cursor=pointer]
    - button "Sign out" [active] [ref=e10] [cursor=pointer]
```

# Test source

```ts
  1  | /**
  2  |  * Shared test helpers and credentials for the Construction PM Portal E2E suite.
  3  |  */
  4  | 
  5  | export const CREDENTIALS = {
  6  |   admin: {
  7  |     email: 'admin@construction.com',
  8  |     password: 'Admin',
  9  |     role: 'Admin',
  10 |   },
  11 |   pm: {
  12 |     email: 'pm@construction.com',
  13 |     password: 'Pm',
  14 |     role: 'PM',
  15 |   },
  16 |   contractor: {
  17 |     email: 'gc@construction.com',
  18 |     password: 'Gc',
  19 |     role: 'Contractor',
  20 |   },
  21 | };
  22 | 
  23 | /**
  24 |  * Log in via the login form and wait for navigation to complete.
  25 |  * @param {import('@playwright/test').Page} page
  26 |  * @param {{ email: string, password: string }} creds
  27 |  */
  28 | export async function login(page, creds) {
  29 |   await page.goto('/login');
  30 |   await page.locator('#email').fill(creds.email);
  31 |   await page.locator('#password').fill(creds.password);
  32 |   await page.locator('button[type="submit"]').click();
  33 |   // Wait until we leave the login page
  34 |   await page.waitForURL((url) => !url.pathname.endsWith('/login'), { timeout: 15_000 });
  35 | }
  36 | 
  37 | /**
  38 |  * Log out via the "Sign out" button and wait for redirect to /login.
  39 |  * @param {import('@playwright/test').Page} page
  40 |  */
  41 | export async function logout(page) {
  42 |   // Find any button with "Sign out" text regardless of class/location
  43 |   await page.getByRole('button', { name: /sign out/i }).first().click();
> 44 |   await page.waitForURL('**/login', { timeout: 15_000 });
     |              ^ TimeoutError: page.waitForURL: Timeout 15000ms exceeded.
  45 | }
  46 | 
```